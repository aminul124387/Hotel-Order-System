#include <stdio.h>
#include <stdlib.h>
/* MD Aminul Islam, ID: 182-16-335*/
/* Find The Grade of Student for CIS Department*/
/* Grade = P>70: Distinction , P>60: Merit, p>40: Fail*/

int main()
{
   int emarks;
   printf("                                 ******** Grading System For Students *******: \n\n");
    printf("Please enter a Your mark carefully 0 to 100: \t");
    scanf("%d",&emarks);
    if(emarks<=0 || emarks>=100){
    printf("Error! Please enter a valid mark. Mark must be between 0 to 100\n\n");

    }else{
    if(emarks>=70){
    printf("Your Grade is: Distinction");
    }else if(emarks>=60){
    printf("Your Grade Position is: Merit");
    }else if(emarks>=40){
    printf(" Your Grade Position is: Pass");
    }else{
    printf("You have failed in this Exam: Fail");

    }
  }
}

